﻿using UnityEngine;

namespace Zenject.Tests.ToSubContainerPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
