﻿using UnityEngine;

namespace Zenject.Tests.ToTransientPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
