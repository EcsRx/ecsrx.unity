using System;
using UnityEngine;

namespace Zenject.Tests.ToPrefabResource
{
    public class Norf2 : MonoBehaviour, INorf
    {
    }
}

