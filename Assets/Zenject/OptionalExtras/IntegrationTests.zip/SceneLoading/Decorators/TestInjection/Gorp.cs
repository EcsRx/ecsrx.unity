﻿using UnityEngine;

namespace Zenject.Tests.ToGameObject
{
    public class Gorp
    {
    }
}
