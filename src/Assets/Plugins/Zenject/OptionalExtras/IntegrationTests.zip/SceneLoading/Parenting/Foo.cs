﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Zenject.Tests.SceneParenting
{
    public class Foo : MonoBehaviour
    {
    }
}

