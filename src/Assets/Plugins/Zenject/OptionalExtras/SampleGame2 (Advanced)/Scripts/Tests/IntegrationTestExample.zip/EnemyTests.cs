using Moq;
using UnityEngine;
using Zenject;
using System.Collections;
using UnityEngine.TestTools;
using Zenject.SpaceFighter;
using Assert = ModestTree.Assert;

namespace Zenject.SpaceFighter
{
    public class EnemyTests : ZenjectIntegrationTestFixture
    {
        void CommonInstall()
        {
            PreInstall();

            var gameSettings = GameSettingsInstaller.InstallFromResource(
                "SpaceFighter/GameSettings", Container);

            Container.Bind<EnemyFacade>().FromSubContainerResolve()
                .ByNewPrefab(gameSettings.GameInstaller.EnemyFacadePrefab);

            Container.BindMemoryPool<Bullet, Bullet.Pool>()
                .FromComponentInNewPrefab(gameSettings.GameInstaller.BulletPrefab);

            Container.BindMemoryPool<Explosion, Explosion.Pool>()
                .FromComponentInNewPrefab(gameSettings.GameInstaller.ExplosionPrefab);

            GameSignalsInstaller.Install(Container);

            // Don't care about these so just mock them out
            Container.Bind<IPlayer>().FromMock().AsSingle();
            Container.Bind<IAudioPlayer>().FromMock().AsSingle();

            PostInstall();
        }

        [Inject]
        EnemyFacade _enemy;

        [UnityTest]
        public IEnumerator TestEnemyStateChanges()
        {
            CommonInstall();

            // Should always start by chasing the player
            Assert.IsEqual(_enemy.State, EnemyStates.Follow);

            // Wait a frame for AI logic to run
            yield return null;

            // Our player mock is always at position zero, so if we move the _enemy there then the _enemy
            // should immediately go into attack mode
            _enemy.Position = Vector3.zero;

            // Wait a frame for AI logic to run
            yield return null;

            Assert.IsEqual(_enemy.State, EnemyStates.Attack);

            _enemy.Position = new Vector3(100, 100, 0);

            // Wait a frame for AI logic to run
            yield return null;

            // The enemy is very far away now, so it should return to searching for the player
            Assert.IsEqual(_enemy.State, EnemyStates.Follow);
        }
    }
}
